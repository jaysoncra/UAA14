﻿// See https://aka.ms/new-console-template for more information


Console.WriteLine("Etat des feux :");
Console.WriteLine(-----------------);
